from django.contrib import admin
from myApp.models import Member, ProblemReporting
# Register your models here.
admin.site.register(Member)
admin.site.register(ProblemReporting)

