from django.contrib import admin
from django.urls import path, include
from myApp import views

urlpatterns = [
    path("", views.index, name="index"),
    path("about/", views.about, name="about"),
    path("contact/", views.contact, name="contact"),
    path("tourism/", views.tourism, name="tourism"),
    path("education/", views.education, name="education"),
    path("health/", views.health, name="health"),
    path("bill/", views.bill, name="bill"),
    path("public_safety/", views.publicsafety, name="publicsafety"),
    path("report_problem/", views.report_problem, name="report_problem"),
    path("signin/", views.signin, name="signin"),
    path("signup/", views.signup, name="signup"),
    path('codeginger02/unapproved-users/', views.show_unapproved_users, name='show_unapproved_users'),
    path('codeginger02/send-confirmation-emails/', views.send_confirmation_emails, name='send_confirmation_emails'),
    path('activate/<str:token>/', views.activate_account, name='activate_account'),
    path('loggedin/', views.loggedin, name='loggedin'),
    path('report_problem/success_reporting.html/', views.success_reporting, name='success_reporting'),
    path('loggedin/active-members/', views.active_members, name='active_members'),
    path('loggedin/news/', views.news_for_members, name='news_for_members'),
]