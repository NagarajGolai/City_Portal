import smtplib

try:
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()  # Upgrade to secure connection
    server.login('codeginger02@gmail.com', 'cikp bbma blow rroh')
    print("Connection successful!")
    server.quit()
except Exception as e:
    print(f"Error: {e}")
