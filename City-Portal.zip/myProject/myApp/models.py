from django.db import models
from django.utils import timezone

# Create your models here.
class Member(models.Model):
    name = models.CharField(max_length=30)
    email = models.EmailField(max_length=40)
    pass1 = models.CharField(max_length=20)
    pass2 = models.CharField(max_length=20)
    date = models.DateField(default=timezone.now)
    is_active = models.BooleanField(default=False)  # For account activation status
    activation_token = models.CharField(max_length=100, null=True, blank=True)  # For storing activation token

    def __str__(self):
            return self.name

# Problem Reporting
class ProblemReporting(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    address = models.CharField(max_length=100, default='Unknown')
    description = models.TextField()

    def __str__(self):
        return self.name
