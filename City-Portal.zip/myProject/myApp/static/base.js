document.addEventListener("DOMContentLoaded", (event) => {
    const blurDiv = document.getElementById("s4BGDiv");
    const s4 = document.getElementById("section4");
  
    memButton[0].addEventListener('click',login);
    blurDiv.addEventListener('click',unblock);
  
    function unblock(){
      s4.style.display = 'none';
    }
    function login(){
      s4.style.display = 'block';
    }
  
  
  });
  