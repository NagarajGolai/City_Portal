document.addEventListener("DOMContentLoaded", (event) => {
  const left = document.getElementById("leftButton");
  const right = document.getElementById("rightButton");
  const container = document.getElementById("imgContainer");
  const images = document.getElementsByClassName("imgs");

  let place;
  function leftFunction() {
    for (let i = 0; i < images.length; i++) {
      place = parseInt(images[i].style.left) || 0;
      images[i].style.left = place + 400 + "px";
    }
  }

  function rightFunction() {
    for (let i = 0; i < images.length; i++) {
      place = parseInt(images[i].style.left) || 0;
      images[i].style.left = place - 400 + "px";
    }
  }

  left.addEventListener("click", leftFunction);
  right.addEventListener("click", rightFunction);

});
