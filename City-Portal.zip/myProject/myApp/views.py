from django.shortcuts import render, HttpResponse
from django.contrib.auth.models import User
from django.shortcuts import redirect
from django.contrib import messages
from datetime import datetime
from myApp.models import Member, ProblemReporting
from django.contrib.auth import authenticate, login


def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, "about.html")

def contact(request):
    return render(request, 'contact.html')

def tourism(request):
    return render(request, "tourism.html")

def education(request):
    return render(request, 'education.html')

def health(request):
    return render(request, 'health.html')

def bill(request):
    return render(request, 'bill.html')

def publicsafety(request):
    return render(request, 'public_safety.html')

# Problem Reporting
def report_problem(request):
    if request.method == 'POST':
        name = request.POST.get('probName')
        email = request.POST.get('probEmail')
        phone = request.POST.get('probPhone')
        address = request.POST.get('probAddress')
        description = request.POST.get('probDescription')

        ProblemReporting.objects.create(name=name, email=email, phone=phone, description=description, address=address)
        # messages.success(request, "Problem reported successfully!")
        return redirect('success_reporting')  # Replace 'success' with your success page's URL name
    return render(request, 'report_problem.html')

def loggedin(request):
    return render(request, 'loggedin.html')

# views.py
from django.shortcuts import render
from .models import Member

def active_members(request):
    active_members_list = Member.objects.filter(is_active=True)  # Fetch active members
    return render(request, 'active_members.html', {'members': active_members_list})


def success_reporting(request):
    messages.success(request, "Your problem has been successfully reported! As website admins, we've logged it, and the authorized offices will take it from here.")
    return render(request, 'success_reporting.html')

def signin(request):
    if request.method == 'POST':
        email = request.POST.get('email')  # Get email from the form
        password = request.POST.get('password')  # Get password from the form

        try:
            # Check if the user exists in the database
            user = Member.objects.get(email=email)
            
            # Verify password and active status
            if user.pass1 == password:
                if user.is_active:  # Check if the user is active
                    messages.success(request, f'Welcome back, {user.name}!')
                    return redirect('loggedin')  # Redirect to the homepage or dashboard
                else:
                    messages.error(request, 'Your account is not active. Please contact support.')
            else:
                messages.error(request, 'Invalid credentials. Please try again.')

        except Member.DoesNotExist:
            messages.error(request, 'User not found. Please sign up first.')

        return redirect('signin')

    return render(request, 'signin.html')

def signup(request):  
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        pass1 = request.POST.get('pass1')
        pass2 = request.POST.get('pass2')

        if pass1 == pass2:
            member = Member(name = name, email = email, pass1 = pass1, pass2 = pass2, date = datetime.today())
            member.save()

            messages.success(request, 'You have signed up on our website. Kindly wait for the approval. You will notified by your e-mail once you are verified!')

            return redirect('signin')

        else:
            messages.success(request, "Password error!")

            return redirect('signup')
        
    return render(request, 'signup.html')

# News Field
def news_for_members(request):
    return render(request, 'newsForMembers.html')

# Email Confirmation
from django.core.mail import send_mail
from django.conf import settings
from django.utils.crypto import get_random_string

def generate_activation_token():
    return get_random_string(length=32)

def send_activation_email(user):
    activation_link = f"http://192.168.19.55:8000/activate/{user.activation_token}/"  # Update with your domain
    activation_link_pc = f"http://127.0.0.1/activate/{user.activation_token}/"  # Update with your domain
    subject = "Activate Your Account"
    message = f"Hi {user.name},\nPhone\nClick the link below to activate your account:\n{activation_link}\n\nThank you!\n\nComputer\nClick the link below to activate your account:\n{activation_link}\n\nThank you!"
    from_email = settings.EMAIL_HOST_USER
    recipient_list = [user.email]
    send_mail(subject, message, from_email, recipient_list)

# Admin's interface
from django.shortcuts import render
from django.http import JsonResponse
from .models import Member

def show_unapproved_users(request):
    unapproved_users = Member.objects.filter(is_active=False)
    return render(request, "approve_users.html", {"users": unapproved_users})

def send_confirmation_emails(request):
    if request.method == "POST":
        user_ids = request.POST.getlist("user_ids")
        selected_users = Member.objects.filter(id__in=user_ids, is_active=False)

        for user in selected_users:
            user.activation_token = generate_activation_token()
            user.save()
            send_activation_email(user)

        messages.success(request,  f"{len(selected_users)} users have been successfully informed via email. Hope they login soon to check out!")
        # return redirect('email_sent')    
        return JsonResponse({"message": f"{len(selected_users)} users have been successfully informed via email. Hope they login soon to check out!"})
    # return render(request, "email_sent.html")
    return JsonResponse({"error": "Invalid request method."}, status=400)

#Action view
def activate_account(request, token):
    try:
        user = Member.objects.get(activation_token=token, is_active=False)
        user.is_active = True
        user.activation_token = None
        user.save()
        return HttpResponse("Your account has been verified! Please login once to make sure..!")
    except Member.DoesNotExist:
        return HttpResponse("Invalid or expired activation link.")

